package com.example.Demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {
	
	@GetMapping("/get")
	public String getMessage()
	{
		return "welcome to spring boot application with docker";
	}

}
